<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b><?php  echo $SITE_TITLE;?> -v<?= $VERSION;?></b> 
    </div>
    <strong>Copyright &copy; <?=date("Y")?> All rights reserved.</strong>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li>
      </li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <div class="tab-pane" id="control-sidebar-home-tab">
        
      </div>
      <!-- /.tab-pane -->
    </div>
  </aside>
