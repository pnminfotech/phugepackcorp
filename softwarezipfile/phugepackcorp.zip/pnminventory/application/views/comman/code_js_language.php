<script type="text/javascript">
         var Lang_confirm_update_record= '<?= $this->lang->line('confirm_update_record'); ?>';
 </script>