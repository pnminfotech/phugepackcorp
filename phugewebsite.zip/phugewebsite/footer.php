<footer class="footer-wrapper footer-layout1" data-bg-src="assets/img/bg/footer_bg_1.jpg">
      
      <div class="widget-area">
          <div class="container">
              <div class="row justify-content-between">
                  <div class="col-md-6 col-xxl-3 col-xl-4">
                      <div class="widget footer-widget">
                          <div class="themeholy-widget-about">
                              <div class="about-logo"><a href="index.php"><img src="assets/img/Logo.png"
                                          alt="Phuge Packcorp"></a></div>
                              <p class="about-text"> Phuge Packcorp manufacture all styles, in the size and strength you require. Print and fittings can be added to complete your perfect solution.</p>
                              <div class="themeholy-social"><a href="https://www.facebook.com/"><i
                                          class="fab fa-facebook-f"></i></a> <a href="https://www.twitter.com/"><i
                                          class="fab fa-twitter"></i></a> <a href="https://www.linkedin.com/"><i
                                          class="fab fa-linkedin-in"></i></a> <a href="https://www.behance.net/"><i
                                          class="fa-brands fa-behance"></i></a></div>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-6 col-xl-auto">
                      <div class="widget footer-widget">
                          <h3 class="widget_title">Office Address</h3>
                          <div class="themeholy-widget-contact">
                              <div class="info-box">
                                  <p class="info-box_text"><i class="fa-regular fa-map"></i> PHUGE PACKCORP 
S no. 152 C/o High Grade Quality Ent Pvt Ltd,Magazine chowk, Alandi Road Bhosari 412105</p>
                              </div>
                              
                              <div class="info-box">
                                  <p class="info-box_text"><a href="tel:+919028161781" class="info-box_link"><i class="fa-regular fa-phone"></i> +91 9028161781 / +91 9561910874</a></p>
                              </div>
                              <div class="info-box">
                                  <p class="info-box_text"><a href="mailto:phugepackcorp@gmail.com"
                                          class="info-box_link"><i class="fa-regular fa-envelope"></i> phugepackcorp@gmail.com</a></p>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-6 col-xl-auto">
                      <div class="widget widget_nav_menu footer-widget">
                          <h3 class="widget_title">Explore</h3>
                          <div class="menu-all-pages-container">
                              <ul class="menu">
                              <li><a href="index.php">Home</a></li>
                                  <li><a href="about.php">About Us</a></li>
                          
                                  <li><a href="client.php">Client</a></li>
                                  <li><a href="request.php">Free Quote</a></li>
                                  <li><a href="contact.php">Contact Us</a></li>
                              </ul>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-6 col-xl-3">
                  <div class="widget widget_nav_menu footer-widget">
                          <h3 class="widget_title">Our Product</h3>
                          <div class="menu-all-pages-container">
                              <ul class="menu">
                              <li><a href="corrugated-box.php">Corrugated Box</a></li>
                                  <li><a href="wooden-packaging-box.php">Wooden Packaging Box</a></li>
                                  <li><a href="paper-box.php">Paper Box</a></li>
                                  <li><a href="carton-box.php">Carton Box</a></li>
                                
                              </ul>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <div class="copyright-wrap">
          <div class="container">
              <div class="row align-items-center">
                  <div class="col-lg-6">
                      <p class="copyright-text"><i class="fal fa-copyright"></i> 2023 All Rights Reserved By <a
                              href="#">Phuge Packcorp. </a> | Design By <a
                              href="https://pnminfotech.com">PNM INFOTECH</a></p>
                  </div>
                  <div class="col-lg-6">
                      <div class="footer-links">
                      <p class="copyright-text"></p>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </footer>